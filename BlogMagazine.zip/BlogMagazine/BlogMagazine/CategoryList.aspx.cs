﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlogMagazine.Model.BL;
using BlogMagazine.VModel;

public partial class BlogMagazine_CategoryList : BlogMagazine.BasePage
{
    private string[] gvKeys = { "SID" };
    BlogMagazine.Model.BL.新鮮誌 bl新鮮誌 = new BlogMagazine.Model.BL.新鮮誌();
    string categoryID;
    protected void Page_Load(object sender, EventArgs e)
    {
        categoryID = Request.QueryString["SID"];
        SetCategoryName();

        if (!Page.IsPostBack)
        {
            MyBind();
        }

    }

    private void MyBind()
    {
        var datas = bl新鮮誌.Items(categoryID,1);
        gv.DataKeyNames = gvKeys;
        gv.DataSource = datas;
        gv.DataBind();

    }

    protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            HyperLink hyperLinkUrl = (HyperLink)e.Row.FindControl("hyperLinkUrl");
            Label lbl更新日 = (Label)e.Row.FindControl("lbl更新日");
            var SID = gv.DataKeys[e.Row.RowIndex].Values["SID"].ToString();
            hyperLinkUrl.NavigateUrl = String.Format("~/BlogMagazine/MagazineDetail.aspx?categoryID={0}&SID={1}", categoryID, SID);
            lbl更新日.Text = Convert.ToDateTime(lbl更新日.Text).ToString("yyyy-MM-dd");
        }
    }

    private void SetCategoryName()
    {
        var bl代碼表 = new BlogMagazine.Model.BL.代碼表();
        var 單元代碼 = bl代碼表.清單("單元名稱");
        var qry = (from i in 單元代碼
                  where i.代碼編號 == categoryID
                  select i).First();
        lblCategoryName.Text = qry.代碼名稱;      
    }
}