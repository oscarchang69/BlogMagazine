﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlogMagazine;

public partial class BlogMagazine_Index : BlogMagazine.BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
       

        if (!Page.IsPostBack){
            myBind();
        }
    }


    private void myBind()
    {
      
        BlogMagazine.Model.BL.新鮮誌 bl新鮮誌 = new BlogMagazine.Model.BL.新鮮誌();        
        dataList.DataSource = bl新鮮誌.Data();
        dataList.DataBind();
    }

}