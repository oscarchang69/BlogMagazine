﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BlogMagazine_ClickRate : BlogMagazine.BasePage
{
    private string[] gvKeys = { "SID", "單元代碼"};
    BlogMagazine.Model.BL.新鮮誌 bl新鮮誌 = new BlogMagazine.Model.BL.新鮮誌();
    string categoryID;
    protected void Page_Load(object sender, EventArgs e)
    {   

        if (!Page.IsPostBack)
        {
            MyBind();
        }

    }

    private void MyBind()
    {
        var datas = bl新鮮誌.ClickRate(30);
        gv.DataKeyNames = gvKeys;
        gv.DataSource = datas;
        gv.DataBind();

    }

    protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            HyperLink hyperLinkUrl = (HyperLink)e.Row.FindControl("hyperLinkUrl");
            Label lbl更新日 = (Label)e.Row.FindControl("lbl更新日");
            Label lbl點閱率 = (Label)e.Row.FindControl("lbl點閱率");
            var SID = gv.DataKeys[e.Row.RowIndex].Values["SID"].ToString();
            var 單元代碼 = gv.DataKeys[e.Row.RowIndex].Values["單元代碼"].ToString();
            hyperLinkUrl.NavigateUrl = String.Format("~/BlogMagazine/MagazineDetail.aspx?categoryID={0}&SID={1}", 單元代碼, SID);
            lbl更新日.Text = Convert.ToDateTime(lbl更新日.Text).ToString("yyyy-MM-dd");
            lbl點閱率.Text = "點閱數：" + Convert.ToInt32(lbl點閱率.Text).ToString("000") + "次";
        }

    }

    private void SetCategoryName()
    {
       

    }
}