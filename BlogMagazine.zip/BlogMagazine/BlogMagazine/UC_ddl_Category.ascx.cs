﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlogMagazine.VModel;

public partial class BlogMagazine_UC_ddl_Category : System.Web.UI.UserControl
{
    public string 使用者單位 { get; set; }
    public event EventHandler ChangedIndex;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

        }

    }

    public void MyBind()
    {
        BlogMagazine.Model.BL.權限 bl權限 = new BlogMagazine.Model.BL.權限();
        List<VM維護權限> list權限清單 = bl權限.Get維護權限清單(使用者單位);
        ddl_Category.DataSource = list權限清單;
        ddl_Category.DataTextField = "單元名稱";
        ddl_Category.DataValueField = "單元代碼";
        ddl_Category.DataBind();

    }


    public string SelectedValue()
    {
        return ddl_Category.SelectedValue;
    }

    public void SetSelectValue(string value)
    {
        ddl_Category.SelectedValue = value;
    }



    protected void ddl_Category_SelectedIndexChanged(object sender, EventArgs e)
    {
        ChangedIndex(this, new MyEvent { SelectedValue = this.SelectedValue() });     
      
    }
}

public class MyEvent : EventArgs
{
    public string SelectedValue { get; set; }
}