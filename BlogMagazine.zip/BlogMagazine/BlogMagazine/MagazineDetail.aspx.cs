﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlogMagazine.Model;
using BlogMagazine.VModel;
using BlogMagazine.Model.BL;

public partial class BlogMagazine_MagazineDetail : BlogMagazine.BasePage
{
    private string SID;
    private string categoryID;
    private BlogMagazine.Model.BL.新鮮誌 bl新鮮誌 = new BlogMagazine.Model.BL.新鮮誌();
    protected void Page_Load(object sender, EventArgs e)
    {     

        SID = Request.QueryString["SID"].ToString();
        categoryID = Request.QueryString["categoryID"].ToString();

        if (!Page.IsPostBack)
        {
            MyBind();
        }
    }

    private void MyBind()
    {
        var data = bl新鮮誌.Item(Convert.ToInt32(SID));
        literalContent.Text = data.內文;
        lblTitle.Text = data.抬頭;

        //點閱次數累計
        var bl點閱紀錄 = new BlogMagazine.Model.BL.點閱紀錄();

        bl點閱紀錄.AddVisited(data.SID, new My.PortalUser(Context.User.Identity.Name).staff_no);

    }
}