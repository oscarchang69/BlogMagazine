﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlogMagazine.VModel;


public partial class BlogMagazine_UC_IndexCategoryBox : System.Web.UI.UserControl
{
    public string 單元名稱 { get; set; }
    public string 單元代號 { get; set; }
    public string imgUrl { get; set; }
    public List<VM新鮮誌_Item> 資料 { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        lblTitleNo.Text = this.單元代號 + ". ";
        lblTitle.Text = this.單元名稱;
        //imgItem.ImageUrl = imgUrl +  Guid.NewGuid().ToString();        
        //imgItem.ImageUrl = imgUrl + String.Format("index{0}.jpg",單元代號);   
        imgItem.ImageUrl = imgUrl;       
        imgItem.PostBackUrl = String.Format("~/BlogMagazine/CategoryList.aspx?SID={0}", 單元代號);
        dataList.DataSource = 資料;
        dataList.DataBind();
    }

}