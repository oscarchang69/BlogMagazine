﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlogMagazine.Model;

public partial class BlogMagazine_admin_Index : System.Web.UI.Page
{
    #region 成員定義
    private  My.PortalUser portalUser;
    private string _使用單位代號;
    private string _維護人員代號;
    private string _wrongImg = "~/BlogMagazine/Content/imgs/wrong.gif";
    private string _rightImg = "~/BlogMagazine/Content/imgs/right.jpg";
    private string[] gvKey = { "SID", "狀態" };
    private enum CtrlState
    {
        新增 = 0,
        編輯 = 1,
        取消 = 2
    }
    private BlogMagazine.Model.BL.新鮮誌 bl新鮮誌 = new BlogMagazine.Model.BL.新鮮誌();
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        portalUser = new My.PortalUser(Context.User.Identity.Name);
        _使用單位代號 = portalUser.unit.unit_id;
        _維護人員代號 = portalUser.staff_no;

         if (!this.User.IsInRole("新鮮誌"))
        {
            //Page.ClientScript.RegisterStartupScript(this.Page.GetType(), Guid.NewGuid().ToString(), "alert('您無權限進入')", true);          
            Response.Redirect("Deny.aspx");
        }

        if (!Page.IsPostBack)
        {
            CtrlButton(CtrlState.新增);
            MyBind();

        }

        //註冊事件
        uc_qry_ddl_Category.ChangedIndex += Uc_qry_ddl_Category_ChangedIndex;
        uc_ddl_Category.ChangedIndex += Uc_ddl_Category_ChangedIndex;

    }

    private void Uc_ddl_Category_ChangedIndex(object sender, EventArgs e)
    {
        
    }

    #region UserControl事件
    private void Uc_qry_ddl_Category_ChangedIndex(object sender, EventArgs e)
    {
        GetGVData();
    }
    #endregion

    #region gv事件
    protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            var lbl最後更新日 = e.Row.FindControl("lbl最後更新日") as Label;
            lbl最後更新日.Text = Convert.ToDateTime(lbl最後更新日.Text).ToString("yyyy-MM-dd");
        }
    }
    protected void gv_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        var rtnResult = bl新鮮誌.刪除(Convert.ToInt32(gv.DataKeys[e.RowIndex].Values["SID"].ToString()));

        if (rtnResult == "True")
        {
            設定彈出訊息("操作指引-刪除文章", "完章已刪除", _rightImg);
        }
        else
        {
            設定彈出訊息("操作指引-刪除失敗", rtnResult, _wrongImg);
        }

        MyBind();
    }
    protected void gv_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        //先將每個編輯按鈕狀態回歸到編輯
        foreach (GridViewRow i in gv.Rows)
        {
            if (i.RowIndex != e.NewSelectedIndex)
            {
                Button btn = (Button)gv.Rows[i.RowIndex].FindControl("btnEdit");
                btn.Text = "編輯";
                btn.BackColor = System.Drawing.Color.Transparent;
                btn.ForeColor = System.Drawing.Color.Black;
            }
        }

        BlogMagazine.VModel.VM新鮮誌_Item obj = bl新鮮誌.Item((int)gv.DataKeys[e.NewSelectedIndex].Values["SID"]);
        EditForm(obj);

        var btnEdit = (Button)gv.Rows[e.NewSelectedIndex].FindControl("btnEdit");
        switch (btnEdit.Text)
        {
            case "編輯":
                btnEdit.Text = "取消編輯";
                //gv.Rows[e.NewSelectedIndex].BackColor = System.Drawing.Color.Turquoise;
                btnEdit.BackColor = System.Drawing.Color.Red;
                btnEdit.ForeColor = System.Drawing.Color.White;
                CtrlButton(CtrlState.編輯);
                break;
            default:
                btnEdit.Text = "編輯";
                //gv.Rows[e.NewSelectedIndex].BackColor = System.Drawing.Color.Transparent;
                //gv.SelectedIndex = -1;
                CtrlButton(CtrlState.取消);
                btnEdit.BackColor = System.Drawing.Color.Transparent;
                btnEdit.ForeColor = System.Drawing.Color.Black;
                ClearForm();
                break;
        }

    }
    #endregion

    #region 方法相關
    private void GetGVData()
    {
        gv.DataKeyNames = gvKey;
        gv.DataSource = bl新鮮誌.Items(uc_qry_ddl_Category.SelectedValue());
        gv.DataBind();
    }
    private void MyBind()
    {

        txt維護單位.Text = _使用單位代號;
        txt維護人員.Text = _維護人員代號;
        uc_ddl_Category.使用者單位 = _使用單位代號;
        uc_ddl_Category.MyBind();
        uc_qry_ddl_Category.使用者單位 = _使用單位代號;
        uc_qry_ddl_Category.MyBind();
        GetGVData();
    }
    private void EditForm(BlogMagazine.VModel.VM新鮮誌_Item obj)
    {
        uc_ddl_Category.SetSelectValue(obj.單元代碼);
        txt維護人員.Text = obj.維護人員員編;
        txt維護單位.Text = obj.維護單位代號;
        ddl狀態.SelectedValue = obj.狀態.ToString();
        txt標題.Text = obj.抬頭;
        summernote.Text = obj.內文;
    }
    private void ClearForm()
    {
        txt標題.Text = "";
        txt維護人員.Text = this._維護人員代號;
        txt維護單位.Text = this._使用單位代號;
        ddl狀態.SelectedIndex = 0;
        summernote.Text = "";
    }
    private void CtrlButton(CtrlState state)
    {
        switch (state)
        {
            case CtrlState.新增:
                btnAdd.Visible = true;
                btnEditSave.Visible = false;
                return;
            case CtrlState.編輯:
                btnAdd.Visible = false;
                btnEditSave.Visible = true;
                return;
            case CtrlState.取消:
                btnAdd.Visible = true;
                btnEditSave.Visible = false;
                return;
        }
    }
    private bool CheckEntry()
    {
        var 標題 = txt標題.Text.Trim();
        var 內文 = summernote.Text.Trim();

        if (標題.Length == 0)
        {
            設定彈出訊息("操作指引-輸入有誤", "請輸入標題", _wrongImg);
            return false;
        }
        else if (內文.Length == 0)
        {
            設定彈出訊息("操作指引-輸入有誤", "請輸入內文", _rightImg);
            return false;
        }
        return true;
    }
    private void 設定彈出訊息(string titleMsg, string BodyMsg, string imgBody)
    {
        if (imgBody.Length == 0)
        {
            ((Image)Page.Master.FindControl("imgModalBody")).Visible = false;
        }
        else
        {
            ((Image)Page.Master.FindControl("imgModalBody")).ImageUrl = imgBody;
        }

        ((Label)Page.Master.FindControl("lblModalTItle")).Text = titleMsg;
        ((Label)Page.Master.FindControl("lblModalBody")).Text = BodyMsg;
        Page.ClientScript.RegisterStartupScript(Page.GetType(), "alert", "showAlert()", true);
    }
    private void SetAlertConfig(AlertConfig alertConfig)
    {
        if (alertConfig.傳回結果 == "True")
        {
            設定彈出訊息(alertConfig.成功標題, alertConfig.成功內文, _rightImg);
            MyBind();
            ClearForm();
        }
        else
        {
            設定彈出訊息(alertConfig.失敗標題, alertConfig.失敗內文, _wrongImg);
        }
    }
    #endregion

    #region 按鈕相關
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (CheckEntry())
        {
            var rtnResult = bl新鮮誌.新增(new BlogMagazine.VModel.VM新鮮誌_Item
            {
                單元代碼 = uc_ddl_Category.SelectedValue(),
                維護單位代號 = txt維護單位.Text.Trim(),
                維護人員員編 = txt維護人員.Text.Trim(),
                狀態 = Convert.ToInt16(ddl狀態.SelectedValue),
                內文 = summernote.Text.Trim(),
                抬頭 = txt標題.Text.Trim()
            });

            SetAlertConfig(new AlertConfig
            {
                傳回結果 = rtnResult,
                成功標題 = "操作指引-成功",
                成功內文 = "新增文章完成",
                失敗標題 = "操作指引-失敗",
                失敗內文 = rtnResult
            });        

        }
    }
    protected void btn清除_Click(object sender, EventArgs e)
    {
        ClearForm();
    }
    protected void btnEditSave_Click(object sender, EventArgs e)
    {
        if (CheckEntry())
        {
            var rtnResult = bl新鮮誌.修改(new BlogMagazine.VModel.VM新鮮誌_Item
            {
                單元代碼 = uc_ddl_Category.SelectedValue(),
                維護單位代號 = _使用單位代號,
                維護人員員編 = _維護人員代號,
                狀態 = Convert.ToInt16(ddl狀態.SelectedValue),
                內文 = summernote.Text.Trim(),
                抬頭 = txt標題.Text.Trim(),
                SID = Convert.ToInt32(gv.DataKeys[gv.SelectedIndex].Values["SID"].ToString())
            });

            SetAlertConfig(new AlertConfig
            {
                傳回結果 = rtnResult,
                成功標題 = "操作指引-成功",
                成功內文 = "修改文章完成",
                失敗標題 = "操作指引-失敗",
                失敗內文 = rtnResult
            });
            
        }
    }
    #endregion

    public class AlertConfig
    {
        public string 傳回結果 { get; set; }
        public string 成功標題 { get; set; }
        public string 成功內文 { get; set; }
        public string 失敗標題 { get; set; }
        public string 失敗內文 { get; set; }        
    }

    protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv.PageIndex = e.NewPageIndex;
        MyBind();
    }
}