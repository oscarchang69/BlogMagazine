﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class BlogMagazine_test_TestAuth : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (User.Identity.IsAuthenticated == false)
        {
            Response.Redirect("~/desktopdefault.aspx");
        }
        else
        {
            uc_ddl_Category.使用者單位 = new My.PortalUser(Context.User.Identity.Name).unit.unit_id;

            //var user = new My.PortalUser(Context.User.Identity.Name);
            //BlogMagazine.Model.BL.權限 bl權限 = new BlogMagazine.Model.BL.權限();
            //List<VM維護權限> list權限清單 = bl權限.Get維護權限清單(user.unit.unit_id);
            //ddl單元.DataSource = list權限清單;
            //ddl單元.DataTextField = "單元名稱";
            //ddl單元.DataValueField = "單元代碼";
            //ddl單元.DataBind();
        }
    }
}