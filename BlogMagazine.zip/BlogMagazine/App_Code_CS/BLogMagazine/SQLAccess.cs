﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// 撰寫者：張君廉
/// </summary>

namespace OLib.DB
{
    public static class SQLAccess
    {
        public static string ExecuteSQL(string conString, string sqlString, CommandType commandType, params SqlParameter[] sqlParams)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand
            {
                Connection = con,
                CommandText = sqlString,
                CommandType = commandType,
            };

            foreach (SqlParameter item in sqlParams)
            {
                cmd.Parameters.Add(item);
            }

            try
            {
                cmd.ExecuteNonQuery();
                return "True";

            }
            catch (Exception e)
            {
                return e.Message.ToString();
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }


        }

        public static DataTable QuerySQL(string conString, string sqlString, CommandType commandType, params SqlParameter[] sqlParams)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlDataReader dr;
            DataTable dt = new DataTable();
            con.Open();
            SqlCommand cmd = new SqlCommand
            {
                Connection = con,
                CommandText = sqlString,
                CommandType = commandType
            };

            foreach (SqlParameter item in sqlParams)
            {
                cmd.Parameters.Add(item);
            }

            dr = cmd.ExecuteReader();
            dt.Load(dr);
            con.Close();
            cmd.Dispose();
            dr.Close();
            return dt;
        }

    }
}
