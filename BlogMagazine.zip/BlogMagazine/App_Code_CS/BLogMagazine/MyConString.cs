﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// ConnectionString 的摘要描述
/// </summary>

namespace BlogMagazine
{
    public static class MyConString
    {
        public static string BlogMagazineConString = System.Configuration.ConfigurationManager.ConnectionStrings["BlogMagazineConString"].ToString();
    }

}