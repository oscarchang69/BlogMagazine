﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogMagazine.VModel;

/// <summary>
/// 登入 的摘要描述
/// </summary>


namespace BlogMagazine
{
    public class 登入者資訊
    {
        VM使用者 _vm使用者;

        public 登入者資訊(string 使用者名稱, string 單位名稱, string 所屬單位, string 所屬角色)
        {
            _vm使用者 = new VM使用者
            {
                使用者名稱 = 使用者名稱,
                單位名稱 = 單位名稱,
                所屬單位 = 所屬單位,
                所屬角色 = 所屬角色
            };
        }
    }

}

