﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// BasePage 的摘要描述
/// </summary>
namespace BlogMagazine
{
    public class BasePage:System.Web.UI.Page
    {
        public BasePage()
        {            
        }

        protected override void OnLoad(EventArgs e)
        {
            if (!User.Identity.IsAuthenticated)
            {
                //Response.Redirect("~/DesktopDefault.aspx");
                Response.Redirect("~/Admin/AccessDenied.aspx");
            }
            base.OnLoad(e); 
        }

    }
}