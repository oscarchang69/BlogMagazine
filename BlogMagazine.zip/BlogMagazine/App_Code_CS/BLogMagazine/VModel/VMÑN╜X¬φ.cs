﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OLib.DB;


/// <summary>
/// VM代碼 的摘要描述
/// </summary>
namespace BlogMagazine.VModel
{
    public class VM代碼表
    {
        public string 代碼編號 { get; set; }
        public string 種類 { get; set; }
        public string 代碼名稱 { get; set; }

    }
}