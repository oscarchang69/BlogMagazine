﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// VM新鮮誌 的摘要描述
/// </summary>

namespace BlogMagazine.VModel
{
    public class VM新鮮誌
    {
        public string 代號 { get; set; }
        public string 名稱 { get; set; }
        public List<VM新鮮誌_Item> 資料 { get; set; }
    }
}