﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// VM點閱紀錄 的摘要描述
/// </summary>
/// 

namespace BlogMagazine.VModel
{
    public class VM點閱紀錄
    {
        public int SID { get; set; }
        public string 單元代碼 { get; set; }
        public string 抬頭 { get; set; }
        public string 維護人員員編 { get; set; }
        public string 點閱員工 { get; set; }
        public DateTime 點閱時間 { get; set; }     
    }
}