﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// VM新鮮誌單元 的摘要描述
/// </summary>
namespace BlogMagazine.VModel
{
    public class VM新鮮誌_Item
    {
        public int SID { get; set; }
        public string 單元代碼 { get; set; }
        public string 單元名稱 { get; set; }
        public string 抬頭 { get; set; }
        public string 內文 { get; set; }
        public string 維護單位 { get; set; }
        public string 維護人員 { get; set; }
        public string 維護單位代號 { get; set; }
        public string 維護人員員編 { get; set; }
        public int 狀態 { get; set; }
        public string 狀態名稱 { get; set; }
        public int 點閱率 { get; set; }
        public DateTime 最後更新日 { get; set; }
        public DateTime 寫入日期  { get; set; }
        public string DetailUrl
        {
            get
            {
                return String.Format("~/BlogMagazine/MagazineDetail.aspx?categoryID={0}&SID={1}", 單元代碼, SID);
            }
        }
    }
}