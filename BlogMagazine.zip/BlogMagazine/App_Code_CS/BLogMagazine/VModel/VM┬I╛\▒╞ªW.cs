﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// VM點閱排名 的摘要描述
/// </summary>
namespace BlogMagazine.VModel
{
    public class VM點閱排名
    {
        public int SID { get; set; }
        public string 單元代碼 { get; set; }
        public string 抬頭 { get; set; }
        public int 點閱數 { get; set; }
    }
}