﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogMagazine.Model.DB;
using BlogMagazine.VModel;
/// <summary>
/// 點閱紀錄 的摘要描述
/// </summary>
namespace BlogMagazine.Model.BL
{
    public class 點閱紀錄
    {
        
        public List<VM點閱紀錄> Items()
        {
            return DB.點閱紀錄.Items();
        }

        public List<VM點閱排名> ItemsVisitedSort()
        {
            return DB.點閱紀錄.ItemsVisitedSort();
        }

        public string AddVisited(int SID, string VisitEmpNo)
        {
            return DB.點閱紀錄.AddVisited(SID, VisitEmpNo);
        }
    }
}