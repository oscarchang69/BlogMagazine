﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogMagazine.Model.DB;
using BlogMagazine.VModel;


/// <summary>
/// 新鮮誌 的摘要描述
/// </summary>

namespace BlogMagazine.Model.BL
{
    public class 新鮮誌
    {
        public List<VM新鮮誌_Item> Items()
        {
            return DB.新鮮誌.Items();
        }

        //public List<VM新鮮誌_Item> Items(bool status)
        //{
        //    var datas = DB.新鮮誌.Items();           
        //    if (status)
        //    {
        //        var rtnData = from i in datas
        //                where i.狀態 == 1
        //                select i;
        //        return rtnData.ToList();
        //    }
        //    else
        //    {
        //        var rtnData = from i in datas
        //                where i.狀態 == 0
        //                select i;
        //        return rtnData.ToList();
        //    }
          
        //}

        public List<VM新鮮誌_Item> Items(string 單元代碼)
        {
            var items = this.Items();
            var qry = (from i in items
                      where i.單元代碼 == 單元代碼
                      select i).OrderByDescending(x=>x.最後更新日);
            return qry.ToList(); 
        }


        public List<VM新鮮誌_Item> Items(string 單元代碼,int status)
        {
            var items = this.Items();
            var qry = (from i in items
                      where 
                        i.單元代碼 == 單元代碼 &&
                        i.狀態== status
                       select i).OrderByDescending(x=>x.最後更新日);
            return qry.ToList();
        }       


        public VM新鮮誌_Item Item(int SID)
        {
            var items = this.Items();
            var qry = from i in items
                      where i.SID == SID
                      select i;
            return qry.First();

        }

        public List<VM新鮮誌> Data()
        {
            return DB.新鮮誌.Data();
        }       

        public string 新增(VM新鮮誌_Item newObj)
        {
            return DB.新鮮誌.新增(newObj);
        }

        public string 刪除(int SID)
        {
            return DB.新鮮誌.刪除(SID);
        }

        public string 修改(VM新鮮誌_Item obj)
        {
            return DB.新鮮誌.修改(obj);
        }

        public List<VM新鮮誌_Item> ClickRate(int TopRate)
        {
            return DB.新鮮誌.ClickRate(TopRate);
        }
    }

}