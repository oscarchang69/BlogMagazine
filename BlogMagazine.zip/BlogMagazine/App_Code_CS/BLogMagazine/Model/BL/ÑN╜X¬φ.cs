﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogMagazine.Model.DB;
using BlogMagazine.VModel;

/// <summary>
/// 代碼表 的摘要描述
/// </summary>
/// 

namespace BlogMagazine.Model.BL
{

    public class 代碼表
    {
        public List<VM代碼表> 清單()
        {
            return DB.代碼表.清單();
        }


        public List<VM代碼表> 清單(string 種類)
        {
            var qry = from i in 清單()
                      where i.種類 == 種類
                      select i;
            return qry.ToList<VM代碼表>();           
        }


    }

}