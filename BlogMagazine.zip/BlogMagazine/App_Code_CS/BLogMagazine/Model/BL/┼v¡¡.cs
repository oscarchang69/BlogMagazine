﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogMagazine.VModel;

/// <summary>
/// 權限 的摘要描述
/// </summary>

namespace BlogMagazine.Model.BL
{

    public class 權限
    {
        
        public List<VM維護權限> Get維護權限清單()
        {
            return DB.權限.Get維護權限清單();
        }

        public List<VM維護權限> Get維護權限清單(string 使用者單位)
        {
            var qry = from i in Get維護權限清單()
                      where i.負責部門 == 使用者單位
                      select i;
            return qry.ToList();
        }

        
        
    }

   
   


}