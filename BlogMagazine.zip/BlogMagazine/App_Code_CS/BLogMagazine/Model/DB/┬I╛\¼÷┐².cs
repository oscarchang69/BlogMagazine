﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using BlogMagazine.VModel;
using OLib.DB;
using System.Data.SqlClient;

/// <summary>
/// 點閱紀錄 的摘要描述
/// </summary>

namespace BlogMagazine.Model.DB
{



    public class 點閱紀錄
    {
        public static List<VM點閱紀錄> Items()
        {
            var rtnList = new List<VM點閱紀錄>();
            var result = SQLAccess.QuerySQL(
                MyConString.BlogMagazineConString,
                @"
                    SELECT
	                    A.SID,
                        A.單元代碼,
	                    A.抬頭,
	                    A.維護單位代號,
	                    A.維護人員員編,
	                    B.點閱員工,
	                    B.點閱時間
                    FROM [dbo].[誌主檔] A JOIN [dbo].[點閱紀錄] B
                    ON
	                    A.SID=B.SID
                ",
                System.Data.CommandType.Text
                );

            foreach (DataRow i in result.Rows)
            {
                var obj = new VM點閱紀錄
                {
                    SID = (int)i["SID"],
                    單元代碼 = (string)i["單元代碼"],
                    抬頭 = (string)i["抬頭"],
                    維護人員員編 = (string)i["維護人員員編"],
                    點閱員工 = (string)i["點閱員工"],
                    點閱時間 = (DateTime)i["點閱時間"]
                };
                rtnList.Add(obj);
            }
            return rtnList;
        }

        public static List<VM點閱排名> ItemsVisitedSort()
        {
            var rtnData = new List<VM點閱排名>();
            var listGroupBySort = (
                                from i in Items()
                                group i by new { i.SID, i.抬頭,i.單元代碼 } into g
                                select new
                                {
                                    SID = g.Key.SID,
                                    抬頭 = g.Key.抬頭,
                                    單元代碼=g.Key.單元代碼,
                                    點閱率 = g.Count()
                                }
                            ).OrderByDescending(x => x.點閱率);       
            
            foreach(var item in listGroupBySort)
            {
                rtnData.Add(new VM點閱排名
                {
                    SID = item.SID,
                     單元代碼 =item.單元代碼,
                    抬頭 = item.抬頭,
                    點閱數 = item.點閱率
                });
            }

            return rtnData;

        }       

        public static string AddVisited(int SID,string VisitEmpNo)
        {
            var rtnResult = SQLAccess.ExecuteSQL(
                MyConString.BlogMagazineConString,
                @"
                    INSERT INTO 點閱紀錄
                    (
	                    SID,
	                    點閱員工,
	                    點閱時間
                    ) 
                    VALUES
                    (
	                    @SID,
	                    @點閱員工,
	                    @點閱時間
                    ) 
                ",
                CommandType.Text,
                new SqlParameter("@SID", SID),
                new SqlParameter("@點閱員工", VisitEmpNo),
                new SqlParameter("@點閱時間", DateTime.Now)
                );

            return rtnResult;
        }

    }
}