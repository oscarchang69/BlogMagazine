﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OLib.DB;
using BlogMagazine;
using System.Data;
using BlogMagazine.VModel;

/// <summary>
/// 權限 的摘要描述
/// </summary>


namespace BlogMagazine.Model.DB
{

    public class 權限
    {
        public static List<VM維護權限> Get維護權限清單()
        {
            var rtnResult = new List<VM維護權限>();
            var dt = SQLAccess.QuerySQL(
                  MyConString.BlogMagazineConString,
                  @"
                    SELECT 
	                    單元代碼=A.單元代碼,
	                    單元名稱=C.代碼名稱,
	                    負責部門=A.負責部門,
	                    負責部門名稱=B.unit_ch_short_name 
                    FROM BlogMagazine..[權限_部門] A JOIN util_db..UNIT B 
                    ON
	                    A.負責部門=B.unit_id
                    JOIN (SELECT * FROM BlogMagazine..代碼表 WHERE 種類='單元名稱')C
                    ON
	                    A.單元代碼=C.代碼編號
                  ",
                  System.Data.CommandType.Text
                  );

            foreach (DataRow i in dt.Rows)
            {
                var obj = new VM維護權限
                {
                    單元代碼 = i["單元代碼"].ToString(),
                    單元名稱 = i["單元名稱"].ToString(),
                    負責部門 = i["負責部門"].ToString(),
                    負責部門名稱 = i["負責部門名稱"].ToString()
                };

                rtnResult.Add(obj);
            }

            return rtnResult;

        }


    }

}