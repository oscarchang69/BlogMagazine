﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OLib.DB;
using BlogMagazine.VModel;
using System.Data;
using System.Data.SqlClient;
using BlogMagazine;




/// <summary>
/// 新鮮誌 的摘要描述
/// </summary>

namespace BlogMagazine.Model.DB
{
    public class 新鮮誌
    {

        public static List<VM新鮮誌_Item> Items()
        {
            var rtnList = new List<VM新鮮誌_Item>();
            var dt = SQLAccess.QuerySQL(
                MyConString.BlogMagazineConString,
                @"
                    SELECT
	                    A.SID, 
	                    單元代碼,
	                    單元名稱=B.代碼名稱, 
	                    抬頭, 
	                    內文, 
	                    維護單位代號, 
	                    維護單位=C.unit_ch_name,
	                    維護人員員編, 
	                    維護人員=D.姓名,
	                    點閱率=ISNULL(F.點閱率,0),
	                    狀態,
	                    狀態名稱=E.代碼名稱, 
	                    最後更新日, 
	                    寫入日期
                    FROM [誌主檔] A JOIN (SELECT * FROM [dbo].[代碼表] WHERE 種類='單元名稱')B
                    ON
	                    A.單元代碼=B.代碼編號
                    LEFT JOIN util_db..UNIT C
                    ON
	                    A.維護單位代號=C.unit_id
                    LEFT JOIN HR..Person D
                    ON
	                    CAST(A.維護人員員編 AS INT)=D.員工號碼
                    JOIN (SELECT 代碼編號,代碼名稱 FROM 代碼表 WHERE 種類='狀態')E
                    ON
	                    A.狀態=CAST(E.代碼編號 AS INT)
                    LEFT JOIN (
			                    SELECT
				                    SID,
				                    點閱率=COUNT(*)
			                    FROM [點閱紀錄]
			                    GROUP BY
				                    SID
			                    )F
                    ON
	                    A.SID=F.SID
                ",
                CommandType.Text
                );

            foreach (DataRow i in dt.Rows)
            {
                var obj = new VM新鮮誌_Item
                {
                    SID = (int)i["SID"],
                    單元代碼 = i["單元代碼"].ToString().Trim(),
                    單元名稱 = i["單元名稱"].ToString().Trim(),
                    抬頭 = i["抬頭"].ToString().Trim(),
                    內文 = i["內文"].ToString().Trim(),
                    維護單位 = i["維護單位"].ToString().Trim(),
                    維護人員 = i["維護人員"].ToString().Trim(),
                    維護單位代號 = i["維護單位代號"].ToString().Trim(),
                    維護人員員編 = i["維護人員員編"].ToString().Trim(),
                    點閱率 = (int)i["點閱率"],
                    狀態 = (int)i["狀態"],
                    狀態名稱 = i["狀態名稱"].ToString().Trim(),
                    最後更新日 = (DateTime)i["最後更新日"],
                    寫入日期 = (DateTime)i["寫入日期"]

                };
                rtnList.Add(obj);
            }
            return rtnList;
        }

        public static List<VM新鮮誌> Data()
        {
            var rtnList = new List<VM新鮮誌>();
            var list_新鮮誌種類 = DB.代碼表.清單("單元名稱");
            var list_Items = Items();

            foreach (VM代碼表 i in list_新鮮誌種類)
            {
                var qryItem = from item in list_Items
                              where
                                item.單元代碼 == i.代碼編號 &&
                                item.狀態 == 1
                              select item;

                rtnList.Add(new VM新鮮誌
                {
                    代號 = i.代碼編號,
                    名稱 = i.代碼名稱,
                    資料 = qryItem.ToList<VM新鮮誌_Item>()
                });
            }

            return rtnList;
        }

        public static string 新增(VM新鮮誌_Item newObj)
        {
            var rtnMsg = SQLAccess.ExecuteSQL(
                  MyConString.BlogMagazineConString,
                  @"
                    INSERT INTO 誌主檔
                    (
	                    單元代碼, 
	                    抬頭, 
	                    內文, 
	                    維護單位代號, 
	                    維護人員員編, 
	                    狀態, 
	                    最後更新日
                    )
                    VALUES
                    (
	                    @單元代碼, 
	                    @抬頭, 
	                    @內文, 
	                    @維護單位代號, 
	                    @維護人員員編, 
	                    @狀態, 
	                    @最後更新日
                    )
                  ",
                  CommandType.Text,
                  new SqlParameter("@單元代碼", newObj.單元代碼),
                  new SqlParameter("@抬頭", newObj.抬頭),
                  new SqlParameter("@內文", newObj.內文),
                  new SqlParameter("@維護單位代號", newObj.維護單位代號),
                  new SqlParameter("@維護人員員編", newObj.維護人員員編),
                  new SqlParameter("@狀態", newObj.狀態),
                  new SqlParameter("@最後更新日", DateTime.Now.ToString("yyyy/MM/dd"))
                  );
            return rtnMsg;
        }

        public static string 刪除(int SID)
        {
            var rtnResult = SQLAccess.ExecuteSQL(
                MyConString.BlogMagazineConString,
                @"
                   DELETE FROM 誌主檔 WHERE SID=@SID
                ",
                CommandType.Text,
                new SqlParameter("@SID", SID)
                );
            return rtnResult;
        }

        public static string 修改(VM新鮮誌_Item obj)
        {
            var rtnResult = SQLAccess.ExecuteSQL(
                MyConString.BlogMagazineConString,
                @"
                    UPDATE 誌主檔
                    SET
	                    單元代碼=@單元代碼, 
	                    抬頭=@抬頭, 
	                    內文=@內文, 
	                    維護單位代號=@維護單位代號, 
	                    維護人員員編=@維護人員員編, 
	                    狀態=@狀態, 
	                    最後更新日=@最後更新日
                    WHERE NULL IS NULL
	                    AND SID=@SID
                ",
                CommandType.Text,
                new SqlParameter("@單元代碼", obj.單元代碼),
                new SqlParameter("@抬頭", obj.抬頭),
                new SqlParameter("@內文", obj.內文),
                new SqlParameter("@維護單位代號", obj.維護單位代號),
                new SqlParameter("@維護人員員編", obj.維護人員員編),
                new SqlParameter("@狀態", obj.狀態),
                new SqlParameter("@最後更新日", DateTime.Now.ToString("yyyy/MM/dd")),
                new SqlParameter("@SID", obj.SID)
                );
            return rtnResult;
        }

        public static List<VM新鮮誌_Item> ClickRate(int TopRate)
        {
            var topRate = (from i in Items()
                           where i.點閱率 > 0
                           select i)
                           .OrderByDescending(p => p.點閱率)
                           .ThenBy(p => p.最後更新日)
                           .Take(TopRate);
            return topRate.ToList();
        }

    }
}