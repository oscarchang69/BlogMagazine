﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OLib.DB;
using BlogMagazine.VModel;
using System.Data;



/// <summary>
/// 代碼表 的摘要描述
/// </summary>

namespace BlogMagazine.Model.DB
{

    public class 代碼表
    {

        public static List<VM代碼表> 清單()
        {
            var rtnList = new List<VM代碼表>();
            var dt = SQLAccess.QuerySQL(
                BlogMagazine.MyConString.BlogMagazineConString,
                @"
                SELECT
	                代碼編號,
	                種類,
	                代碼名稱
                FROM 代碼表
            ",
                CommandType.Text
                );

            foreach (DataRow i in dt.Rows)
            {
                var obj = new VM代碼表
                {
                    代碼名稱 = i["代碼名稱"].ToString().Trim(),
                    代碼編號 = i["代碼編號"].ToString().Trim(),
                    種類 = i["種類"].ToString().Trim()
                };
                rtnList.Add(obj);
            }

            return rtnList;
        }

        public static List<VM代碼表> 清單(string 種類)
        {
            var data = 清單();
            var qry = from i in data
                      where i.種類 == 種類
                      select i;
            return qry.ToList();
        }

    }
}