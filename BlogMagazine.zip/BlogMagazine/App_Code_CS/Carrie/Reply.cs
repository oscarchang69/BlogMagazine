﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Carrie
{
    public class Reply
    {
        const bool FAIL = false;
        const bool SUCCESS = true;

        public bool Success { get; set; }
        public string Message { get; set; }
        public string Status { get; set; }
        public object Data { get; set; }
        public Reply(bool success, string message, object data, string status)
        {
            Success = success;
            Message = message;
            Data = data;
            Status = status;
        }
        public void WriteJsonTo(HttpContext ctx)
        {
            var jss = new System.Web.Script.Serialization.JavaScriptSerializer();
            jss.MaxJsonLength = 209715200;
            var json = jss.Serialize(this);
            ctx.Response.ContentType = "application/json";
            ctx.Response.Charset = "utf-8";
            ctx.Response.Write(json);
        }
        public static Reply Error(string message, object data, string status)
        {
            return new Reply(FAIL, message, data, status);
        }
        public static Reply Error(string message, object data)
        {
            return Error(message, data, null);
        }
        public static Reply Error(string message)
        {
            return Error(message, null);
        }
        public static Reply OK(string message, object data, string status)
        {
            return new Reply(SUCCESS, message, data, status);
        }
        public static Reply OK(string message, object data)
        {
            return OK(message, data, null);
        }
        public static Reply OK(string message)
        {
            return OK(message, null);
        }
        public static Reply OK()
        {
            return OK(null);
        }
        public static Reply Obj(object data)
        {
            return OK(null, data);
        }
    }
}