﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;


namespace Carrie
{
    public static class Table
    {
        public static void AddTo(this DataTable table, ref List<Dictionary<string, object>> dic)
        {
            Dictionary<string, object> data;
            dic = new List<Dictionary<string, object>>();
            foreach (DataRow row in table.Rows)
            {
                data = new Dictionary<string, object>();
                data = table.Columns.Cast<DataColumn>().ToDictionary(
                    column => column.ColumnName,
                    column => row[column.ColumnName]
                    );
                dic.Add(data);
            }
        }

    }

    public enum ActionMode
    {
        Select,
        Insert,
        Update,
        Delete,
        Void
    }

    public class Parameter
    {
        /// <summary>
        /// Parameter Name
        /// </summary>
        public string ParaName { get; set; }
        /// <summary>
        /// Request Name
        /// </summary>
        public string ReqName { get; set; }
    }
}