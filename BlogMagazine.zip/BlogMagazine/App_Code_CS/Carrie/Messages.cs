﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Carrie
{

    /// <summary>
    /// Summary description for Messages
    /// </summary>
    public static class Messages
    {
        public const string Saved = "儲存成功";
        public const string Deleted = "刪除成功";
        public const string Voided = "作廢成功";
    }
}