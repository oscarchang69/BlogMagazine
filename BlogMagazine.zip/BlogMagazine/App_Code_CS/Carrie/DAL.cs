﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL
/// </summary>
namespace Carrie
{
    public class DAL
    {
        public static void Insert(HttpContext ctx, string commandText, string connStr)
        {
            ExcuteBase(ctx, commandText, connStr, ActionMode.Insert);
        }

        public static void Select(HttpContext ctx, string commandText, string connStr)
        {
            ExcuteBase(ctx, commandText, connStr, ActionMode.Select);
        }

        public static void Update(HttpContext ctx, string commandText, string connStr)
        {
            ExcuteBase(ctx, commandText, connStr, ActionMode.Update);
        }

        public static void Delete(HttpContext ctx, string commandText, string connStr)
        {
            ExcuteBase(ctx, commandText, connStr, ActionMode.Delete);
        }
        public static void Void(HttpContext ctx, string commandText, string connStr)
        {
            ExcuteBase(ctx, commandText, connStr, ActionMode.Void);
        }
        private static void ExcuteBase(HttpContext ctx, string commandText, string connStr, ActionMode mode)
        {
            try
            {
                List<SqlParameter> paras = new List<SqlParameter>();
                if (ctx.Request["paraString"] != null)
                    ctx.Request["paraString"].Split(',').ToList().ForEach(o => paras.Add(P(o, ctx.Request[o])));
                    
                ExcuteBase(ctx, commandText, connStr, paras.ToArray(), mode);
            }
            catch (Exception ex)
            {
                Reply.Error(ex.Message).WriteJsonTo(ctx);
            }
        }

        //public static void ExcuteBase(HttpContext ctx, string commandText, string connStr, List<string> paraList, ActionMode mode)
        //{
        //    try
        //    {
        //        List<SqlParameter> paras = new List<SqlParameter>();
        //        paraList.ForEach(o => paras.Add(P(o, ctx.Request[o])));
        //        ExcuteBase(ctx, commandText, connStr, paras.ToArray(), mode);
        //    }
        //    catch (Exception ex)
        //    {
        //        Reply.Error(ex.Message).WriteJsonTo(ctx);
        //    }
        //}

        private static void ExcuteBase(HttpContext ctx, string commandText, string connStr, SqlParameter[] paras, ActionMode mode)
        {
            try
            {
                List<Dictionary<string, object>> root = new List<Dictionary<string, object>>();
                DataTable table = new DataTable();
                ExecuteReader(r =>
                {
                    table.Load(r);
                    table.AddTo(ref root);
                }, commandText, connStr, paras);

                switch (mode)
                {
                    case ActionMode.Select:
                        Reply.Obj(root).WriteJsonTo(ctx);
                        break;
                    case ActionMode.Update:
                    case ActionMode.Insert:
                        Reply.OK(Messages.Saved, root).WriteJsonTo(ctx);
                        break;
                    case ActionMode.Delete:
                        Reply.OK(Messages.Deleted, root).WriteJsonTo(ctx);
                        break;
                    case ActionMode.Void:
                        Reply.OK(Messages.Voided, root).WriteJsonTo(ctx);
                        break;
                }
            }
            catch (Exception ex)
            {
                Reply.Error(ex.Message).WriteJsonTo(ctx);
            }
        }

        public static SqlParameter P(string name, object value)
        {
            return new SqlParameter(name, value);
        }

        public static void ExecuteReader(Action<SqlDataReader> callback, string commandText, string connStr, params SqlParameter[] parameters)
        {
            ConnectToDatabase(connection =>
            {
                using (var command = new SqlCommand(commandText, connection))
                {
                    command.Parameters.AddRange(parameters);
                    using (var reader = command.ExecuteReader())
                    {
                        callback(reader);
                    }
                }
            }, connStr);
        }

        public static void ConnectToDatabase(Action<SqlConnection> callback, string connStr)
        {
            using (var connection = new SqlConnection(connStr))
            {
                connection.Open();
                callback(connection);
            }
        }
    }
}