﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Carrie
{
    /// <summary>
    /// Summary description for Util
    /// </summary>
    public static class Util
    {
        public static string IsAuthorized(string targetRoles, string currentRoles)
        {
            try
            {
                return (targetRoles.Split(';').Intersect(currentRoles.Split(',')).Any()).ToString().ToLower();
            }
            catch
            {
                return "false";
            }
        }
    }
}