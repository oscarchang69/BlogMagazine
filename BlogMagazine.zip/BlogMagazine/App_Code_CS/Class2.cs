﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Class2 的摘要描述
/// </summary>
public class Class2
{
    public Class2()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
    }


    public string sayHiFromC()
    {
        return "Hi C#";
    }
}