﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace Ferdinand.MobileWeb1Backend
{
    public static class Utility
    {
        public static string ImagePath
        {
            get { return "~/MobileWeb1Backend/AllData/Images/"; }
        }

        /// <summary>
        /// 爬日期字串 (ex.2014/01/14) 轉DateTime
        /// </summary>
        /// <param name="theDay">日期字串</param>
        /// <returns>日期</returns>
        public static DateTime ParseDateString(string theDay)
        {
            try
            {
                return Convert.ToDateTime(theDay);
            }
            catch
            {
                return new DateTime();
            }
        }

        /// <summary>
        /// 做分頁
        /// </summary>
        /// <param name="itemsPerPage">每頁多少資料</param>
        /// <param name="totalItem">所有的資料數</param>
        /// <param name="currentPage">現在在第幾頁</param>
        /// <param name="url">網址位置</param>
        /// <returns>回傳html內容</returns>
        public static string BindingPager(int itemsPerPage, int totalItem, int currentPage, string url)
        {
            string tmplPrev = "<li><a href=\"{0}\" aria-label=\"Previous\"><span aria-hidden=\"true\">&laquo;</span></a></li>";
            string tmplNext = "<li><a href=\"{0}\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
            string tmplMid = "<li {0}><a href=\"{1}\">{2}</a></li>";

            int showPageCount = 2;

            int totalPage = (totalItem + itemsPerPage - 1) / itemsPerPage;
            int fromPage = currentPage - showPageCount > 0 ? currentPage - showPageCount : 1;
            int endPage = currentPage + showPageCount < totalPage ? currentPage + showPageCount : totalPage;

            string s = "";
            if (fromPage > 1)
            {
                s += String.Format(tmplPrev, url + "?p=" + (currentPage - 1));
            }

            for (int i = fromPage; i <= endPage; i++)
            {
                if (i != currentPage)
                {
                    s += String.Format(tmplMid, "", url + "?p=" + i, i);
                }
                else
                {
                    s += String.Format(tmplMid, "class=\"active\"", url + "?p=" + i, i);
                }
            }

            if (endPage < totalPage)
            {
                s += String.Format(tmplNext, url + "?p=" + (currentPage + 1));
            }

            return s;
        }

        /// <summary>
        /// 過版到前台
        /// </summary>
        /// <param name="filePath">本機檔案路徑</param>
        /// <param name="targetPath">FTP檔案路徑</param>
        /// <returns>有沒有錯誤</returns>
        public static string FtpUpload(string filePath,string targetPath)
        {
            string errstr="";
            string errFtpIP = "";
            string FtpIP = System.Configuration.ConfigurationManager.AppSettings["MobileWebFtpIP"];
            string acct = System.Configuration.ConfigurationManager.AppSettings["MobileWebFtpAcct"];
            string pwd = System.Configuration.ConfigurationManager.AppSettings["MobileWebFtpPwd"];
            // 這邊要抽到config
            try
            {
                errFtpIP = "ftp://" + FtpIP + "/" + targetPath;
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://" + FtpIP + "/" + targetPath);
                request.Method = WebRequestMethods.Ftp.UploadFile;
                request.Credentials = new NetworkCredential(acct, pwd);

                byte[] fileContents = File.ReadAllBytes(filePath);
                request.ContentLength = fileContents.Length;

                Stream requestStream = request.GetRequestStream();
                requestStream.Write(fileContents, 0, fileContents.Length);
                requestStream.Close();

                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                response.Close();

                //若測試環境：同步上傳到外部網站
                if (FtpIP == "172.18.3.2")
                {
                    errFtpIP = "ftp://172.18.4.4/" + targetPath;
                    FtpWebRequest request2 = (FtpWebRequest)WebRequest.Create("ftp://172.18.4.4/" + targetPath);
                    request2.Method = WebRequestMethods.Ftp.UploadFile;
                    request2.Credentials = new NetworkCredential(acct, pwd);

                    byte[] fileContents2 = File.ReadAllBytes(filePath);
                    request2.ContentLength = fileContents2.Length;

                    Stream requestStream2 = request2.GetRequestStream();
                    requestStream2.Write(fileContents2, 0, fileContents2.Length);
                    requestStream2.Close();

                    FtpWebResponse response2 = (FtpWebResponse)request2.GetResponse();
                    response2.Close();
                }
            }
            catch (Exception e)
            {
                errstr = errFtpIP + e.Message;
            }
            return errstr;
        }


        public static string FtpDelete(string targetPath)
        {
            string errstr = "";
            string errFtpIP = "";
            string FtpIP = System.Configuration.ConfigurationManager.AppSettings["MobileWebFtpIP"];
            string acct = System.Configuration.ConfigurationManager.AppSettings["MobileWebFtpAcct"];
            string pwd = System.Configuration.ConfigurationManager.AppSettings["MobileWebFtpPwd"];
            // 這邊要抽到config
            try
            {
                errFtpIP = "ftp://" + FtpIP + "/" + targetPath;
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://" + FtpIP + "/" + targetPath);
                request.Credentials = new NetworkCredential(acct, pwd);
                request.Method = WebRequestMethods.Ftp.DeleteFile;

                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                response.Close();

                //若測試環境：同步刪除外部網站檔案
                if (FtpIP == "172.18.3.2")
                {
                    errFtpIP = "ftp://172.18.4.4/" + targetPath;
                    FtpWebRequest request2 = (FtpWebRequest)WebRequest.Create("ftp://172.18.4.4/" + targetPath);
                    request2.Credentials = new NetworkCredential(acct, pwd);
                    request2.Method = WebRequestMethods.Ftp.DeleteFile;

                    FtpWebResponse response2 = (FtpWebResponse)request2.GetResponse();
                    response2.Close();
                }
            }
            catch (Exception e)
            {
                errstr = errFtpIP + e.Message;
            }
            return errstr;
        }


        public static bool IsManager(string staff_no, string name)
        {
            var lstManager = File.ReadAllText(HttpContext.Current.Server.MapPath("~/MobileWeb1Backend/AllData/Manager/manager.dat")).Split(new string[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            return lstManager.Any(m => m == staff_no + "," + name);
        }


    }
}