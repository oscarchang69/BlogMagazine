﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ferdinand.MobileWeb1Backend.Model
{
    public class Banner
    {
        public string Id { set; get; }

        /// <summary>
        /// 類型
        /// </summary>
        public string type { set; get; }

        /// <summary>
        /// 建立者姓名
        /// </summary>
        public string CreateName { set; get; }

        /// <summary>
        /// 建立者員編
        /// </summary>
        public string CreateNum { set; get; }

        /// <summary>
        /// 刪除日期
        /// </summary>
        public DateTime DeleteDate { set; get; }

        /// <summary>
        /// 刪除者姓名
        /// </summary>
        public string DeleteName { set; get; }

        /// <summary>
        /// 刪除者員編
        /// </summary>
        public string DeleteNum { set; get; }

        /// <summary>
        /// 審核者姓名
        /// </summary>
        public string ValidateName { set; get; }

        /// <summary>
        /// 審核者員編
        /// </summary>
        public string ValidateNum { set; get; }

        /// <summary>
        /// 建立日期
        /// </summary>
        public DateTime CreateDate { set; get; }

        /// <summary>
        /// 圖片檔名
        /// </summary>
        public string ImageName { set; get; }

        /// <summary>
        /// 網址，非必填
        /// </summary>
        public string RedirectUrl { set; get; }

        /// <summary>
        /// 標題
        /// </summary>
        public string Title { set; get; }

        /// <summary>
        /// 描述，非必填
        /// </summary>
        public string Description { set; get; }

        /// <summary>
        /// 上架日期
        /// </summary>
        public DateTime BeginDate { set; get; }

        /// <summary>
        /// 結束日期
        /// </summary>
        public DateTime EndDate { set; get; }

        /// <summary>
        /// 是否上架顯示
        /// </summary>
        public bool IsShelving { set; get; }

        /// <summary>
        /// 主管是否審核通過
        /// </summary>
        public bool IsManagerValidation { set; get; }

        /// <summary>
        /// 審核日期
        /// </summary>
        public DateTime ValidateDate { set; get; }

        /// <summary>
        /// 原審核者姓名(已審核再修改才會使用)
        /// </summary>
        public string ValidateName_Old { set; get; }

        /// <summary>
        /// 原審核者員編(已審核再修改才會使用)
        /// </summary>
        public string ValidateNum_Old { set; get; }

        /// <summary>
        /// 原建立日期(已審核再修改才會使用)
        /// </summary>
        public DateTime CreateDate_Old { set; get; }

        /// <summary>
        /// 原圖片檔名(已審核再修改才會使用)
        /// </summary>
        public string ImageName_Old { set; get; }

        /// <summary>
        /// 原網址(已審核再修改才會使用)
        /// </summary>
        public string RedirectUrl_Old { set; get; }

        /// <summary>
        /// 原標題(已審核再修改才會使用)
        /// </summary>
        public string Title_Old { set; get; }

        /// <summary>
        /// 原描述(已審核再修改才會使用)
        /// </summary>
        public string Description_Old { set; get; }

        /// <summary>
        /// 原上架日期(已審核再修改才會使用)
        /// </summary>
        public DateTime BeginDate_Old { set; get; }

        /// <summary>
        /// 原結束日期(已審核再修改才會使用)
        /// </summary>
        public DateTime EndDate_Old { set; get; }
    }
}