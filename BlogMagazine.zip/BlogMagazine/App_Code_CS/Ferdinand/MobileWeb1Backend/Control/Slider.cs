﻿using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.Script.Serialization;
using System.Linq;
using System;

namespace Ferdinand.MobileWeb1Backend.Control
{
    public class Slider
    {
        // 完整位址
        private string GetFullDataPath(string id)
        {
            return HttpContext.Current.Server.MapPath("~/MobileWeb1Backend/AllData/Slider/") + id + ".dat";
        }
        private string GetFullImagePath(string ImageName)
        {
            return HttpContext.Current.Server.MapPath("~/MobileWeb1Backend/AllData/Images/") + ImageName;
        }

        /// <summary>
        /// 新增(如果id一樣會覆蓋掉)
        /// </summary>
        /// <param name="bi">Slider物件</param>
        /// <returns>成功與否</returns>
        public bool Save(Ferdinand.MobileWeb1Backend.Model.Slider bi)
        {
            string s = new JavaScriptSerializer().Serialize(bi);
            File.WriteAllText(GetFullDataPath(bi.Id), s);
            return true;
        }

        /// <summary>
        /// 刪除
        /// </summary>
        /// <param name="id">Slider id</param>
        /// <returns>成功與否</returns>
        public string Delete(string id, string name, string num)
        {
            if (!File.Exists(GetFullDataPath(id)))
            {
                return "檔案不存在";
            }
            Ferdinand.MobileWeb1Backend.Model.Slider b = Get(id);
            b.DeleteDate = DateTime.Now;
            b.DeleteName = name;
            b.DeleteNum = num;
            Save(b);
            //刪除前備份到內網資料夾
            File.Move(GetFullDataPath(id), HttpContext.Current.Server.MapPath("~/MobileWeb1Backend/AllData/Removed/Slider/") + id + ".dat");
            File.Move(GetFullImagePath(b.ImageName), HttpContext.Current.Server.MapPath("~/MobileWeb1Backend/AllData/Removed/Images/") + b.ImageName);
            //刪除FTP的.dat檔案、圖片檔案也要刪...
            string errstr = "";
            errstr += Utility.FtpDelete("Slider/" + b.Id + ".dat");
            errstr += Utility.FtpDelete("Images/" + b.ImageName);
            //發生錯誤回傳錯誤訊息
            return errstr;
        }

        /// <summary>
        /// 取得單一Slider
        /// </summary>
        /// <param name="id">Slider id</param>
        /// <returns>SliderInfo</returns>
        public Ferdinand.MobileWeb1Backend.Model.Slider Get(string id)
        {
            if (!File.Exists(GetFullDataPath(id)))
            {
                // 檔案不存在
                return null;
            }

            string s = File.ReadAllText(GetFullDataPath(id));
            return new JavaScriptSerializer().Deserialize<Ferdinand.MobileWeb1Backend.Model.Slider>(s);
        }

        /// <summary>
        /// 取得所有Slider
        /// </summary>
        /// <returns>Slider list</returns>
        public List<Ferdinand.MobileWeb1Backend.Model.Slider> GetAll()
        {
            string[] allFiles = Directory.GetFiles(HttpContext.Current.Server.MapPath("~/MobileWeb1Backend/AllData/Slider/"));
            return allFiles.Select(f => new JavaScriptSerializer().Deserialize<Ferdinand.MobileWeb1Backend.Model.Slider>(File.ReadAllText(f))).ToList();
        }

        /// <summary>
        /// 主管驗證
        /// </summary>
        /// <param name="Id">Id</param>
        /// <returns>成功與否</returns>
        public string Validate(string Id, string ValidateName, string ValidateNum)
        {
            Ferdinand.MobileWeb1Backend.Model.Slider b = Get(Id);
            b.ValidateName = ValidateName;
            b.ValidateNum = ValidateNum;
            b.ValidateDate = DateTime.Now;
            b.IsManagerValidation = true;
            //核可後將保留的審核前原始資料，清為預設值
            b.BeginDate_Old = new DateTime();
            b.CreateDate_Old = new DateTime();
            b.Description_Old = null;
            b.EndDate_Old = new DateTime();
            if (b.ImageName_Old != null)
            {
                string filePath = HttpContext.Current.Server.MapPath("~/MobileWeb1Backend/AllData/Images/") + b.ImageName_Old;
                //刪除原始圖片
                if (File.Exists(filePath)) { File.Delete(filePath); }
                //刪除FTP原始圖片
                Utility.FtpDelete("Images/" + b.ImageName_Old);
            }
            b.ImageName_Old = null;
            b.RedirectUrl_Old = null;
            b.Title_Old = null;
            b.ValidateName_Old = null;
            b.ValidateNum_Old = null;
            Save(b);

            string errstr = "";
            errstr+=Utility.FtpUpload(HttpContext.Current.Server.MapPath(Utility.ImagePath) + b.ImageName, "Images/" + b.ImageName) ;
            errstr+=Utility.FtpUpload(GetFullDataPath(b.Id), "Slider/" + b.Id + ".dat") ;
            // 發生錯誤回傳錯誤訊息
            return errstr;
        }
    }
}